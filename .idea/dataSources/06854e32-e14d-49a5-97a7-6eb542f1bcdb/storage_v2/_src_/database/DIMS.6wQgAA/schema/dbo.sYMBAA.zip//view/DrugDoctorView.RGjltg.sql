CREATE VIEW DrugDoctorView
AS
SELECT d.PDno, d.PDname, d.PDlife, (d.PDnum - (SELECT COALESCE(SUM(PID.PDnum), 0)
												FROM Prescription p, PID
												WHERE p.Pno = PID.Pno AND p.Pstate = 0
														AND PID.PDno = d.PDno)) AS PDnum
FROM DrugView d
go

