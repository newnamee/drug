CREATE PROCEDURE HandleRx @Pno INT, @Nno VARCHAR(20), @Htime DATETIME, @returnValue SMALLINT OUTPUT
AS
SET XACT_ABORT ON
BEGIN TRAN
DECLARE @RxDrugPDno VARCHAR(20);
DECLARE @RxDrugPDnum SMALLINT;
DECLARE @BatchPDbatch DATE;
DECLARE @BatchPDnum SMALLINT;
SET @returnValue = 0;
DECLARE RxDrugs CURSOR FOR SELECT PDno, PDnum
							FROM PID
							WHERE Pno = @Pno;
OPEN RxDrugs;
FETCH NEXT FROM RxDrugs INTO @RxDrugPDno, @RxDrugPDnum;
WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE Batches CURSOR FOR SELECT PDbatch, PDnum
								FROM InventoryDrug
								WHERE PDno = @RxDrugPDno
								ORDER BY PDbatch ASC;
	OPEN Batches;
	FETCH NEXT FROM Batches INTO @BatchPDbatch, @BatchPDnum;
	WHILE @@FETCH_STATUS = 0 AND @RxDrugPDnum > 0
	BEGIN
		IF @BatchPDnum >= @RxDrugPDnum
		BEGIN
			UPDATE InventoryDrug
			SET PDnum = (PDnum - @RxDrugPDnum)
			WHERE PDno = @RxDrugPDno AND PDbatch = @BatchPDbatch;
			SET @returnValue = @returnValue + @@error;
			SET @RxDrugPDnum = 0;
		END
		ELSE
		BEGIN
			SET @RxDrugPDnum = @RxDrugPDnum - @BatchPDnum;
			UPDATE InventoryDrug
			SET PDnum = 0
			WHERE PDno = @RxDrugPDno AND PDbatch = @BatchPDbatch;
			SET @returnValue = @returnValue + @@error;
		END
		FETCH NEXT FROM Batches INTO @BatchPDbatch, @BatchPDnum;
	END
	CLOSE Batches
	DEALLOCATE Batches
	FETCH NEXT FROM RxDrugs INTO @RxDrugPDno, @RxDrugPDnum;
END
CLOSE RxDrugs
DEALLOCATE RxDrugs
SET @returnValue = @returnValue + @@error;
UPDATE Prescription
SET Nno = @Nno, Htime = @Htime, Pstate = 1
WHERE Pno = @Pno;
SET @returnValue = @returnValue + @@error;
COMMIT TRAN
go

